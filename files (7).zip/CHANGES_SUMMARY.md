# اللي اتعدل فعليًا (index.html + style.css)

الملفات التانية (backlog.html, contact.html, dashboard.html, و كل الـ .css/.js بتاعتهم) **متغيرتش** — مرفقة زي ما هي بس عشان يكون عندك سيت كامل جاهز ترفعه.

## ✅ تعديل 1 — تصحيح تاجات MediTrust (index.html)

```diff
- <div class="card-tags"><span>React</span><span>Three.js</span><span>Node</span></div>
- <p>Full-scale graduation web application featuring 3D interactive drug models and integrated
+ <div class="card-tags"><span>PHP</span><span>MySQL</span><span>QR Auth</span></div>
+ <p>Full-scale graduation web application with an admin dashboard and integrated
```

شلت كمان جملة "3D interactive drug models" من الوصف لأنها مش موجودة في الكود الفعلي (مفيش Three.js ولا أي 3D rendering في MediTrust-Core).

## ✅ تعديل 2 — تقليل قائمة "In Progress" على الصفحة الرئيسية (index.html)

- شلت LogSentry, AuthGuard, NetWatch من الصفحة الرئيسية (سبتهم زي ما هم في backlog.html — كانوا أصلاً موجودين هناك بنفس البيانات كـ "Active Build")
- سبت بس Smart Study Planner (65%) و Fresh Produce Delivery (50%) — الأعلى تقدمًا
- ضفت لينك "View all active builds & ideas →" تحتهم بيوجّه لـ `backlog.html`

## ✅ تعديل 3 — CSS بسيط (style.css)

ضفت كلاس `.view-all-backlog-link` عشان يستايل اللينك الجديد بشكل متسق مع باقي الموقع (نفس الخط، نفس الألوان).

## ⏸️ تعديل 4 — "Last updated" لكل مشروع deployed — **لسه محتاج منك**

مقدرتش أضيفه لأني مش عندي تواريخ حقيقية، ومكنش هيكون صح إني أخترعها. لو بعتلي تاريخ آخر تحديث فعلي (حتى لو تقريبي، زي "أغسطس 2026") لكل مشروع من المشاريع الـ 8 دي:

1. MediTrust Core
2. BTC Admin Node (student-system)
3. Dynamic QR Generator
4. (المشروع اللي بعده)
5. Enterprise Analytics (data-analysis)
6. Atmospheric Data (weather-app)
7. Web-Security-Checker
8. CyberSec Roadmap
9. BugsBunny Framework

هضيفهم فورًا في نفس الملف.

---

## إزاي ترفعهم

كل الملفات هنا (index.html, style.css, وكل الباقي) جاهزة تنزلها وترفعها فوق نفس الأسامي في الريبو بتاع البورتفوليو، أو تعمل commit من المتصفح زي ما شرحنا في `HOW_TO_APPLY.md` قبل كده.
