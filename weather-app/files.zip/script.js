// Weather Station — real current conditions, hourly trend and a
// 7-day outlook, pulled live from Open-Meteo (no key required).

const cityInput = document.getElementById('city-input');
const searchBtn = document.getElementById('search-btn');
const locationBtn = document.getElementById('location-btn');
const loader = document.getElementById('loader');
const dashboard = document.getElementById('dashboard-content');
const alertContainer = document.getElementById('alert-container');
const alertText = document.getElementById('alert-text');

let hourlyChart = null;

// WMO weather codes -> plain description + icon + sky mood
const weatherCodes = {
    0:  { desc: 'Clear sky',            icon: 'fa-sun',                 sky: 'clear' },
    1:  { desc: 'Mostly clear',         icon: 'fa-sun',                 sky: 'clear' },
    2:  { desc: 'Partly cloudy',        icon: 'fa-cloud-sun',           sky: 'cloudy' },
    3:  { desc: 'Overcast',             icon: 'fa-cloud',               sky: 'cloudy' },
    45: { desc: 'Fog',                  icon: 'fa-smog',                sky: 'fog' },
    48: { desc: 'Freezing fog',         icon: 'fa-smog',                sky: 'fog' },
    51: { desc: 'Light drizzle',        icon: 'fa-cloud-rain',          sky: 'rain' },
    53: { desc: 'Drizzle',              icon: 'fa-cloud-rain',          sky: 'rain' },
    55: { desc: 'Dense drizzle',        icon: 'fa-cloud-rain',          sky: 'rain' },
    61: { desc: 'Light rain',           icon: 'fa-cloud-showers-heavy', sky: 'rain' },
    63: { desc: 'Rain',                 icon: 'fa-cloud-showers-heavy', sky: 'rain' },
    65: { desc: 'Heavy rain',           icon: 'fa-cloud-showers-heavy', sky: 'rain' },
    71: { desc: 'Light snow',           icon: 'fa-snowflake',           sky: 'snow' },
    73: { desc: 'Snow',                 icon: 'fa-snowflake',           sky: 'snow' },
    75: { desc: 'Heavy snow',           icon: 'fa-snowflake',           sky: 'snow' },
    95: { desc: 'Thunderstorm',         icon: 'fa-bolt',                sky: 'storm' },
};

const getWeatherInfo = (code) => weatherCodes[code] || { desc: 'Unknown', icon: 'fa-question', sky: 'cloudy' };

function applySkyMood(code, isDay) {
    document.body.className = document.body.className
        .split(' ')
        .filter((c) => !c.startsWith('sky-'))
        .join(' ');

    const info = getWeatherInfo(code);
    const mood = info.sky === 'clear' ? (isDay ? 'clear-day' : 'clear-night') : info.sky;
    document.body.classList.add(`sky-${mood}`);
}

async function getCoordinates(place) {
    const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(place)}&count=1&language=en&format=json`);
    const data = await res.json();
    if (!data.results || data.results.length === 0) throw new Error('not found');
    return data.results[0];
}

async function loadWeather(lat, lon, placeName) {
    dashboard.classList.remove('is-visible');
    dashboard.style.display = 'none';
    alertContainer.style.display = 'none';
    loader.style.display = 'block';

    try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code,is_day&hourly=temperature_2m,relative_humidity_2m&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto`;
        const res = await fetch(url);
        if (!res.ok) throw new Error('bad response');
        const data = await res.json();

        renderCurrent(data, placeName);
        renderChart(data.hourly);
        renderForecast(data.daily);

        loader.style.display = 'none';
        dashboard.style.display = 'block';
        requestAnimationFrame(() => dashboard.classList.add('is-visible'));
    } catch (err) {
        loader.style.display = 'none';
        alertContainer.style.display = 'block';
        alertText.innerHTML = `<strong>Couldn't load the forecast.</strong> The weather service may be unreachable — try again in a moment.`;
        console.error(err);
    }
}

function renderCurrent(data, placeName) {
    const current = data.current;
    const info = getWeatherInfo(current.weather_code);
    applySkyMood(current.weather_code, current.is_day);

    document.getElementById('city-name').textContent = placeName;
    document.getElementById('date-time').textContent = new Date().toLocaleDateString('en-US', {
        weekday: 'long', month: 'long', day: 'numeric',
    });
    document.getElementById('current-temp').textContent = Math.round(current.temperature_2m);
    document.getElementById('weather-desc').textContent = info.desc;
    document.getElementById('current-icon').className = `fas ${info.icon} weather-icon`;
    document.getElementById('current-humidity').textContent = `${current.relative_humidity_2m}%`;
    document.getElementById('current-wind').textContent = `${current.wind_speed_10m} km/h`;

    const severe = current.wind_speed_10m > 40 || current.temperature_2m > 45 || current.weather_code === 95;
    if (severe) {
        alertContainer.style.display = 'block';
        alertText.innerHTML = `<strong>Severe weather right now.</strong> Wind ${current.wind_speed_10m} km/h, ${Math.round(current.temperature_2m)}°C.`;
    }
}

function renderForecast(daily) {
    const grid = document.getElementById('forecast-grid');
    grid.innerHTML = '';

    for (let i = 1; i <= 7; i++) {
        const date = new Date(daily.time[i]);
        const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
        const info = getWeatherInfo(daily.weather_code[i]);
        const hi = Math.round(daily.temperature_2m_max[i]);
        const lo = Math.round(daily.temperature_2m_min[i]);

        const card = document.createElement('div');
        card.className = 'forecast-day';
        card.innerHTML = `
            <h4>${dayName}</h4>
            <i class="fas ${info.icon}"></i>
            <div class="cond">${info.desc}</div>
            <div class="minmax"><span class="hi">${hi}°</span><span class="lo">${lo}°</span></div>
        `;
        grid.appendChild(card);
    }
}

function renderChart(hourly) {
    const ctx = document.getElementById('hourlyChart').getContext('2d');

    const labels = hourly.time.slice(0, 24).map((t) => {
        const d = new Date(t);
        return `${d.getHours().toString().padStart(2, '0')}:00`;
    });
    const temps = hourly.temperature_2m.slice(0, 24);
    const humidity = hourly.relative_humidity_2m.slice(0, 24);

    if (hourlyChart) hourlyChart.destroy();

    Chart.defaults.font.family = "'IBM Plex Sans', sans-serif";
    Chart.defaults.color = '#5C6B73';

    hourlyChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [
                {
                    label: 'Temperature (°C)',
                    data: temps,
                    borderColor: '#C97A2E',
                    backgroundColor: 'rgba(201, 122, 46, 0.08)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true,
                    pointRadius: 0,
                    yAxisID: 'y',
                },
                {
                    label: 'Humidity (%)',
                    data: humidity,
                    borderColor: '#3E6FA6',
                    borderWidth: 1.5,
                    borderDash: [4, 3],
                    tension: 0.3,
                    pointRadius: 0,
                    yAxisID: 'y1',
                },
            ],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 14, padding: 16, font: { size: 11 } } },
                tooltip: {
                    backgroundColor: '#1D2A32',
                    titleColor: '#FCFDFD',
                    bodyColor: '#FCFDFD',
                    borderWidth: 0,
                    padding: 10,
                },
            },
            scales: {
                x: { grid: { display: false } },
                y: { type: 'linear', position: 'left', grid: { color: 'rgba(29, 42, 50, 0.06)' }, ticks: { color: '#C97A2E' } },
                y1: { type: 'linear', position: 'right', grid: { drawOnChartArea: false }, ticks: { color: '#3E6FA6' } },
            },
        },
    });
}

// ---------- interactions ----------

searchBtn.addEventListener('click', async () => {
    const place = cityInput.value.trim();
    if (!place) return;
    searchBtn.disabled = true;
    try {
        const loc = await getCoordinates(place);
        await loadWeather(loc.latitude, loc.longitude, `${loc.name}, ${loc.country}`);
    } catch {
        alertContainer.style.display = 'block';
        alertText.innerHTML = `<strong>Couldn't find that place.</strong> Check the spelling and try again.`;
    } finally {
        searchBtn.disabled = false;
    }
});

cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') searchBtn.click();
});

locationBtn.addEventListener('click', () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
        (pos) => loadWeather(pos.coords.latitude, pos.coords.longitude, 'Your location'),
        () => {
            alertContainer.style.display = 'block';
            alertText.innerHTML = `<strong>Location access was blocked.</strong> Allow it in your browser, or search a city instead.`;
        }
    );
});

// Initial load
getCoordinates('Cairo').then((loc) => loadWeather(loc.latitude, loc.longitude, loc.name));
