// The Ledger — real CSV-driven small-business analytics.
// Upload a transactions CSV (or load the bundled sample dataset) and every
// KPI, chart, and table row below is computed live from that data — nothing
// on screen after load is hand-typed.

Chart.defaults.font.family = "'Work Sans', sans-serif";
Chart.defaults.color = '#6B6255';
Chart.defaults.borderColor = 'rgba(33, 29, 22, 0.08)';

const ink = '#211D16', forest = '#33513F', brick = '#9B3B2C', gold = '#A9792C';
const catPalette = [forest, gold, '#7A8A78', '#8B5E4A', '#4A6B7A', '#B0824A'];

const REQUIRED = ["id", "customer", "amount", "date"];
const COLUMN_ALIASES = {
    id: ["order", "order_id", "id", "orderid", "invoice"],
    customer: ["customer", "customer_name", "name", "client"],
    amount: ["amount", "total", "revenue", "value", "price"],
    date: ["date", "order_date", "created_at", "timestamp"],
    method: ["method", "payment", "payment_method", "paymentmethod"],
    category: ["category", "type", "product_category"],
    status: ["status", "fulfillment", "fulfilled", "state"],
};
const FULFILLED_WORDS = ["fulfilled", "completed", "delivered", "paid", "yes", "done", "shipped"];

let allData = [];
let filteredData = [];
let sortState = { key: "date", dir: "desc" };
let visibleCount = 25;
const PAGE_SIZE = 25;
let charts = {};

// ---------- Column mapping & parsing ----------

function mapHeaders(fields) {
    const map = {};
    const lowerFields = fields.map(f => f.trim().toLowerCase());
    for (const key in COLUMN_ALIASES) {
        for (const alias of COLUMN_ALIASES[key]) {
            const idx = lowerFields.indexOf(alias);
            if (idx !== -1) { map[key] = fields[idx]; break; }
        }
    }
    return map;
}

function normalizeRow(raw, map, index) {
    const amountRaw = String(raw[map.amount] ?? "").replace(/[^0-9.\-]/g, "");
    const amount = parseFloat(amountRaw);
    const dateVal = new Date(raw[map.date]);
    const statusRaw = String(raw[map.status] ?? "fulfilled").trim().toLowerCase();
    return {
        id: String(raw[map.id] ?? `#${1000 + index}`).trim(),
        customer: String(raw[map.customer] ?? "Unknown").trim(),
        amount: isNaN(amount) ? 0 : amount,
        date: isNaN(dateVal.getTime()) ? null : dateVal,
        method: (raw[map.method] ? String(raw[map.method]).trim().toLowerCase() : "card"),
        category: (raw[map.category] ? String(raw[map.category]).trim() : "Other"),
        status: FULFILLED_WORDS.includes(statusRaw) ? "fulfilled" : "pending",
    };
}

function parseCSVFile(file) {
    Papa.parse(file, {
        header: true,
        skipEmptyLines: true,
        complete: (res) => {
            if (!res.data.length || !res.meta.fields) {
                showError(t("errEmpty")); return;
            }
            const map = mapHeaders(res.meta.fields);
            const missing = REQUIRED.filter(k => !map[k]);
            if (missing.length) { showError(t("errColumns", missing)); return; }
            const rows = res.data
                .map((r, i) => normalizeRow(r, map, i))
                .filter(r => r.date && !isNaN(r.amount));
            if (!rows.length) { showError(t("errEmpty")); return; }
            loadDataset(rows, file.name);
            addActivityLine(t("actUploaded", rows.length));
        },
        error: () => showError(t("errParse")),
    });
}

function showError(msg) {
    alert(msg);
}

// ---------- Sample data generator (deterministic pseudo-random) ----------

function mulberry32(seed) {
    return function () {
        seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
        let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

function generateSampleData(n = 180) {
    const rand = mulberry32(42);
    const customers = ["Sara M.","Karim H.","Layla F.","Omar T.","Nour A.","Yassin K.","Hana S.","Mostafa R.",
        "Dina E.","Adam W.","Farida Z.","Sherif B.","Mona Y.","Tarek G.","Rana I.","Ziad N.",
        "Salma Q.","Hassan P.","Amira C.","Youssef D."];
    const categories = ["Retail","Wholesale","Services","Subscriptions","Other"];
    const methods = ["card","transfer","cash"];
    const start = new Date("2026-01-05");
    const rows = [];
    for (let i = 0; i < n; i++) {
        const dayOffset = Math.floor(rand() * 235); // ~ 8 months
        const date = new Date(start.getTime() + dayOffset * 86400000);
        const category = categories[Math.floor(rand() * categories.length)];
        const baseAmount = { Retail: 60, Wholesale: 420, Services: 150, Subscriptions: 35, Other: 90 }[category];
        const amount = Math.round(baseAmount * (0.4 + rand() * 1.8) * 100) / 100;
        // gentle upward growth trend over the period
        const growth = 1 + (dayOffset / 235) * 0.9;
        rows.push({
            id: `#${1000 + i}`,
            customer: customers[Math.floor(rand() * customers.length)],
            amount: Math.round(amount * growth * 100) / 100,
            date,
            method: methods[Math.floor(rand() * methods.length)],
            category,
            status: rand() < 0.91 ? "fulfilled" : "pending",
        });
    }
    return rows.sort((a, b) => b.date - a.date);
}

// ---------- Loading & filters ----------

function loadDataset(rows, sourceName) {
    allData = rows;
    document.getElementById("upload-zone").classList.add("has-data");
    document.getElementById("filter-bar").hidden = false;
    document.getElementById("dataSourceNote").removeAttribute("data-i18n");
    document.getElementById("dataSourceNote").textContent = sourceName
        ? t("subFile", sourceName, rows.length)
        : t("subFile", "sample-data.csv", rows.length);
    populateFilterOptions();
    resetFilterInputs();
    applyFilters();
}

function populateFilterOptions() {
    const cats = [...new Set(allData.map(r => r.category))].sort();
    const methods = [...new Set(allData.map(r => r.method))].sort();
    fillSelect("f-category", cats, t("allCategories"));
    fillSelect("f-method", methods, t("allMethods"));
    fillSelect("f-status", ["fulfilled", "pending"], t("allStatuses"), (v) => t(v === "fulfilled" ? "statusFulfilled" : "statusPending"));
}

function fillSelect(id, values, allLabel, labelFn) {
    const el = document.getElementById(id);
    const prev = el.value;
    el.innerHTML = "";
    const optAll = document.createElement("option");
    optAll.value = ""; optAll.textContent = allLabel;
    el.appendChild(optAll);
    values.forEach(v => {
        const opt = document.createElement("option");
        opt.value = v; opt.textContent = labelFn ? labelFn(v) : v;
        el.appendChild(opt);
    });
    if (values.includes(prev)) el.value = prev;
}

function resetFilterInputs() {
    document.getElementById("f-search").value = "";
    document.getElementById("f-category").value = "";
    document.getElementById("f-method").value = "";
    document.getElementById("f-status").value = "";
    if (allData.length) {
        const dates = allData.map(r => r.date.getTime());
        document.getElementById("f-from").value = new Date(Math.min(...dates)).toISOString().slice(0, 10);
        document.getElementById("f-to").value = new Date(Math.max(...dates)).toISOString().slice(0, 10);
    }
}

function applyFilters(logActivity) {
    const search = document.getElementById("f-search").value.trim().toLowerCase();
    const from = document.getElementById("f-from").value ? new Date(document.getElementById("f-from").value) : null;
    const to = document.getElementById("f-to").value ? new Date(document.getElementById("f-to").value + "T23:59:59") : null;
    const category = document.getElementById("f-category").value;
    const method = document.getElementById("f-method").value;
    const status = document.getElementById("f-status").value;

    filteredData = allData.filter(r => {
        if (search && !(r.customer.toLowerCase().includes(search) || r.id.toLowerCase().includes(search))) return false;
        if (from && r.date < from) return false;
        if (to && r.date > to) return false;
        if (category && r.category !== category) return false;
        if (method && r.method !== method) return false;
        if (status && r.status !== status) return false;
        return true;
    });

    visibleCount = PAGE_SIZE;
    renderAll();
    if (logActivity) addActivityLine(t("actFiltered", filteredData.length));
}

// ---------- KPI computation ----------

function computeKpiSet(data) {
    const revenue = data.reduce((s, r) => s + r.amount, 0);
    const count = data.length;
    const custCounts = {};
    data.forEach(r => custCounts[r.customer] = (custCounts[r.customer] || 0) + 1);
    const repeat = Object.values(custCounts).filter(c => c > 1).length;
    const fulfilled = data.filter(r => r.status === "fulfilled").length;
    const fulfillmentRate = count ? (fulfilled / count) * 100 : 0;
    const aov = count ? revenue / count : 0;
    return { revenue, count, repeat, fulfillmentRate, aov };
}

function splitHalves(data) {
    if (data.length < 2) return [data, []];
    const sorted = [...data].sort((a, b) => a.date - b.date);
    const mid = Math.floor(sorted.length / 2);
    return [sorted.slice(0, mid), sorted.slice(mid)];
}

function renderKpis() {
    const current = computeKpiSet(filteredData);
    const [firstHalf, secondHalf] = splitHalves(filteredData);
    const prev = computeKpiSet(firstHalf);
    const now = computeKpiSet(secondHalf.length ? secondHalf : filteredData);

    document.getElementById("kpi-revenue").textContent = fmtCurrency(current.revenue);
    document.getElementById("kpi-repeat").textContent = fmtNumber(current.repeat);
    document.getElementById("kpi-fulfillment").textContent = current.count ? current.fulfillmentRate.toFixed(1) + "%" : "—";
    document.getElementById("kpi-aov").textContent = fmtCurrency(current.aov);

    setDelta("kpi-revenue-delta", pctDelta(prev.revenue, now.revenue), "%");
    setDelta("kpi-repeat-delta", pctDelta(prev.repeat, now.repeat), "%");
    setDelta("kpi-fulfillment-delta", now.fulfillmentRate - prev.fulfillmentRate, t("ptsShort"), true);
    setDelta("kpi-aov-delta", pctDelta(prev.aov, now.aov), "%");
}

function pctDelta(prev, now) {
    if (!prev) return now ? 100 : 0;
    return ((now - prev) / prev) * 100;
}

function setDelta(elId, value, unit, isPointsDiff) {
    const el = document.getElementById(elId);
    if (!isFinite(value) || filteredData.length < 2) { el.textContent = ""; el.className = "kpi-delta"; return; }
    const rounded = Math.abs(value) < 0.05 ? 0 : value;
    const arrow = rounded > 0 ? "▲" : rounded < 0 ? "▼" : "•";
    const cls = rounded > 0 ? "up" : rounded < 0 ? "down" : "flat";
    const num = isPointsDiff ? Math.abs(rounded).toFixed(1) : Math.abs(rounded).toFixed(1);
    el.textContent = `${arrow} ${num}${unit} ${t("vsPrevPeriod")}`;
    el.className = "kpi-delta " + cls;
}

// ---------- Charts ----------

function destroyCharts() { Object.values(charts).forEach(c => c && c.destroy()); charts = {}; }

function tooltipTheme() {
    return { backgroundColor: '#FBF7EE', titleColor: ink, bodyColor: ink, borderColor: '#C9BEA4', borderWidth: 1, padding: 10 };
}

function renderCharts() {
    destroyCharts();
    if (!filteredData.length) return;

    // group by month
    const byMonth = {};
    filteredData.forEach(r => {
        const key = `${r.date.getFullYear()}-${r.date.getMonth()}`;
        if (!byMonth[key]) byMonth[key] = { revenue: 0, count: 0, y: r.date.getFullYear(), m: r.date.getMonth() };
        byMonth[key].revenue += r.amount;
        byMonth[key].count += 1;
    });
    const months = Object.values(byMonth).sort((a, b) => a.y - b.y || a.m - b.m);
    const labels = months.map(m => monthLabel(m.m));

    charts.revenue = new Chart(document.getElementById('revenueChart').getContext('2d'), {
        type: 'line',
        data: {
            labels,
            datasets: [
                { label: t("revenueLegend"), data: months.map(m => m.revenue), borderColor: forest, backgroundColor: forest, borderWidth: 2, tension: 0.25, pointRadius: 3, pointBackgroundColor: forest, yAxisID: 'y' },
                { label: t("ordersLegend"), data: months.map(m => m.count), borderColor: brick, backgroundColor: brick, borderWidth: 2, borderDash: [4, 3], tension: 0.25, pointRadius: 0, yAxisID: 'y1' }
            ]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: { legend: { position: 'bottom', labels: { color: ink, boxWidth: 14, padding: 16, font: { size: 11 } } }, tooltip: tooltipTheme() },
            scales: {
                x: { grid: { display: false } },
                y: { beginAtZero: true, grid: { color: 'rgba(33,29,22,0.06)' }, ticks: { callback: v => '$' + (v / 1000).toFixed(0) + 'k' } },
                y1: { beginAtZero: true, position: 'right', grid: { display: false } }
            }
        }
    });

    const byCategory = {};
    filteredData.forEach(r => byCategory[r.category] = (byCategory[r.category] || 0) + r.amount);
    const catEntries = Object.entries(byCategory).sort((a, b) => b[1] - a[1]);
    charts.category = new Chart(document.getElementById('sourceChart').getContext('2d'), {
        type: 'doughnut',
        data: { labels: catEntries.map(e => e[0]), datasets: [{ data: catEntries.map(e => e[1]), backgroundColor: catPalette, borderColor: '#FBF7EE', borderWidth: 3, hoverOffset: 3 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '68%',
            plugins: { legend: { position: 'bottom', labels: { color: ink, boxWidth: 12, padding: 14, font: { size: 10.5 } } }, tooltip: { ...tooltipTheme(), callbacks: { label: (ctx) => `${ctx.label}: ${fmtCurrency(ctx.parsed)}` } } } }
    });

    const byCustomer = {};
    filteredData.forEach(r => byCustomer[r.customer] = (byCustomer[r.customer] || 0) + r.amount);
    const topCustomers = Object.entries(byCustomer).sort((a, b) => b[1] - a[1]).slice(0, 6).reverse();
    charts.topCustomers = new Chart(document.getElementById('topCustomersChart').getContext('2d'), {
        type: 'bar',
        data: { labels: topCustomers.map(e => e[0]), datasets: [{ data: topCustomers.map(e => e[1]), backgroundColor: forest }] },
        options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: { ...tooltipTheme(), callbacks: { label: ctx => fmtCurrency(ctx.parsed.x) } } },
            scales: { x: { beginAtZero: true, grid: { color: 'rgba(33,29,22,0.06)' }, ticks: { callback: v => '$' + (v / 1000).toFixed(1) + 'k' } }, y: { grid: { display: false } } } }
    });

    const byMethod = {};
    filteredData.forEach(r => byMethod[r.method] = (byMethod[r.method] || 0) + 1);
    const methodEntries = Object.entries(byMethod);
    charts.method = new Chart(document.getElementById('methodChart').getContext('2d'), {
        type: 'bar',
        data: { labels: methodEntries.map(e => e[0]), datasets: [{ data: methodEntries.map(e => e[1]), backgroundColor: [forest, gold, '#7A8A78', '#8B5E4A'] }] },
        options: { responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: tooltipTheme() },
            scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: 'rgba(33,29,22,0.06)' }, ticks: { precision: 0 } } } }
    });
}

// ---------- Table ----------

function sortedFilteredData() {
    const { key, dir } = sortState;
    const mult = dir === "asc" ? 1 : -1;
    return [...filteredData].sort((a, b) => {
        let va = a[key], vb = b[key];
        if (key === "date") { va = va.getTime(); vb = vb.getTime(); }
        if (key === "amount") { /* numeric already */ }
        else if (typeof va === "string") { va = va.toLowerCase(); vb = vb.toLowerCase(); }
        if (va < vb) return -1 * mult;
        if (va > vb) return 1 * mult;
        return 0;
    });
}

function renderTable() {
    const tbody = document.getElementById("txn-tbody");
    tbody.innerHTML = "";
    document.getElementById("txn-count-note").textContent = t("txnCount", filteredData.length);

    if (!allData.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-note">${t("emptyState")}</td></tr>`;
        document.getElementById("show-more-btn").hidden = true;
        return;
    }
    if (!filteredData.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-note">${t("noMatches")}</td></tr>`;
        document.getElementById("show-more-btn").hidden = true;
        return;
    }

    const sorted = sortedFilteredData();
    const visible = sorted.slice(0, visibleCount);
    visible.forEach(r => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${r.id}</td>
            <td>${r.customer}</td>
            <td>${fmtCurrency(r.amount)}</td>
            <td>${fmtDate(r.date)}</td>
            <td>${r.category}</td>
            <td><span class="tag ${r.method}">${r.method}</span></td>
            <td><span class="tag ${r.status}">${t(r.status === "fulfilled" ? "statusFulfilled" : "statusPending")}</span></td>
        `;
        tbody.appendChild(tr);
    });

    const moreBtn = document.getElementById("show-more-btn");
    const remaining = sorted.length - visible.length;
    if (remaining > 0) {
        moreBtn.hidden = false;
        moreBtn.textContent = t("showMore", Math.min(PAGE_SIZE, remaining));
    } else if (visibleCount > PAGE_SIZE) {
        moreBtn.hidden = false;
        moreBtn.textContent = t("showLess");
    } else {
        moreBtn.hidden = true;
    }

    document.querySelectorAll("thead th[data-sort]").forEach(th => {
        th.classList.toggle("sorted", th.dataset.sort === sortState.key);
        th.classList.toggle("asc", th.dataset.sort === sortState.key && sortState.dir === "asc");
    });
}

// ---------- Activity log ----------

function timeNow() {
    return new Date().toLocaleTimeString(STATE.lang === "ar" ? "ar-EG-u-nu-latn" : "en-US", { hour: "2-digit", minute: "2-digit" });
}

function addActivityLine(text) {
    const list = document.getElementById("activity-list");
    const item = document.createElement("div");
    item.className = "activity-item is-new";
    item.innerHTML = `<span class="activity-time">${timeNow()}</span><span class="activity-text">${text}</span>`;
    list.prepend(item);
    while (list.children.length > 6) list.removeChild(list.lastElementChild);
    setTimeout(() => item.classList.remove("is-new"), 1500);
}

// ---------- Export ----------

function downloadBlob(content, filename, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
}

function exportCSV() {
    const rows = sortedFilteredData();
    if (!rows.length) return;
    const header = "order,customer,amount,date,method,category,status";
    const lines = rows.map(r => [r.id, `"${r.customer}"`, r.amount, r.date.toISOString().slice(0, 10), r.method, r.category, r.status].join(","));
    downloadBlob([header, ...lines].join("\n"), "ledger-export.csv", "text/csv");
    addActivityLine(t("actExported", rows.length));
}

function downloadTemplate() {
    const header = "order,customer,amount,date,method,category,status";
    const sample = [
        "#2001,Jane Doe,120.50,2026-03-14,card,Retail,fulfilled",
        "#2002,John Smith,860.00,2026-03-15,transfer,Wholesale,pending",
    ];
    downloadBlob([header, ...sample].join("\n"), "ledger-template.csv", "text/csv");
}

// ---------- Language switching ----------

function setLanguage(lang) {
    STATE.lang = lang;
    localStorage.setItem("ledger-lang", lang);
    applyStaticTranslations();
    if (allData.length) {
        document.getElementById("dataSourceNote").textContent = t("subFile", document.title, allData.length);
    }
    populateFilterOptions();
    renderAll();
}

// ---------- Master render ----------

function renderAll() {
    renderKpis();
    renderCharts();
    renderTable();
}

// ---------- Wiring ----------

document.addEventListener("DOMContentLoaded", () => {
    applyStaticTranslations();

    document.getElementById("lang-btn").addEventListener("click", () => {
        const next = STATE.lang === "en" ? "ar" : "en";
        setLanguage(next);
        addActivityLine(STRINGS[next].actLangSwitch);
    });

    document.getElementById("sample-btn").addEventListener("click", () => {
        const rows = generateSampleData();
        loadDataset(rows, null);
        addActivityLine(t("actSample", rows.length));
    });

    document.getElementById("upload-btn").addEventListener("click", () => document.getElementById("file-input").click());
    document.getElementById("file-input").addEventListener("change", (e) => {
        if (e.target.files[0]) parseCSVFile(e.target.files[0]);
    });

    const dropZone = document.getElementById("upload-zone");
    ["dragenter", "dragover"].forEach(evt => dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.classList.add("drag-over"); }));
    ["dragleave", "drop"].forEach(evt => dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.classList.remove("drag-over"); }));
    dropZone.addEventListener("drop", (e) => {
        const file = e.dataTransfer.files[0];
        if (file) parseCSVFile(file);
    });

    document.getElementById("template-btn").addEventListener("click", downloadTemplate);
    document.getElementById("export-btn").addEventListener("click", exportCSV);

    ["f-search", "f-from", "f-to", "f-category", "f-method", "f-status"].forEach(id => {
        const el = document.getElementById(id);
        el.addEventListener(id === "f-search" ? "input" : "change", () => applyFilters(true));
    });
    document.getElementById("f-reset").addEventListener("click", () => { resetFilterInputs(); applyFilters(true); });

    document.querySelectorAll("thead th[data-sort]").forEach(th => {
        th.addEventListener("click", () => {
            const key = th.dataset.sort;
            if (sortState.key === key) sortState.dir = sortState.dir === "asc" ? "desc" : "asc";
            else sortState = { key, dir: "asc" };
            renderTable();
        });
    });

    document.getElementById("show-more-btn").addEventListener("click", () => {
        visibleCount = visibleCount > PAGE_SIZE && visibleCount >= filteredData.length ? PAGE_SIZE : visibleCount + PAGE_SIZE;
        renderTable();
    });

    renderTable(); // empty state before any data is loaded
});
