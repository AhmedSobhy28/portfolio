// The Ledger — chart setup and small UI interactions.
// All figures here are sample/demo data for a fictional store,
// used to show how the dashboard looks when it has real numbers in it.

Chart.defaults.font.family = "'Work Sans', sans-serif";
Chart.defaults.color = '#6B6255';
Chart.defaults.borderColor = 'rgba(33, 29, 22, 0.08)';

const ink = '#211D16';
const forest = '#33513F';
const brick = '#9B3B2C';
const gold = '#A9792C';

// 1. Revenue vs operating costs — plain ink lines, no gradient fill.
const revenueCtx = document.getElementById('revenueChart').getContext('2d');
new Chart(revenueCtx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                label: 'Revenue',
                data: [45000, 52000, 68000, 74000, 102000, 124500],
                borderColor: forest,
                backgroundColor: forest,
                borderWidth: 2,
                tension: 0.25,
                pointRadius: 3,
                pointBackgroundColor: forest,
            },
            {
                label: 'Operating costs',
                data: [30000, 32000, 35000, 41000, 48000, 51000],
                borderColor: brick,
                backgroundColor: brick,
                borderWidth: 2,
                borderDash: [4, 3],
                tension: 0.25,
                pointRadius: 0,
            }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
            legend: {
                position: 'bottom',
                labels: { color: ink, boxWidth: 14, padding: 16, font: { size: 11 } }
            },
            tooltip: {
                backgroundColor: '#FBF7EE',
                titleColor: ink,
                bodyColor: ink,
                borderColor: '#C9BEA4',
                borderWidth: 1,
                padding: 10,
            }
        },
        scales: {
            x: { grid: { display: false } },
            y: {
                beginAtZero: true,
                grid: { color: 'rgba(33, 29, 22, 0.06)' },
                ticks: { callback: (v) => '$' + v / 1000 + 'k' }
            }
        }
    }
});

// 2. Where customers come from — muted ledger palette, no neon.
const sourceCtx = document.getElementById('sourceChart').getContext('2d');
new Chart(sourceCtx, {
    type: 'doughnut',
    data: {
        labels: ['Walk-in / repeat', 'Referrals', 'Social', 'Online ads'],
        datasets: [{
            data: [45, 25, 20, 10],
            backgroundColor: [forest, gold, '#7A8A78', '#C9BEA4'],
            borderColor: '#FBF7EE',
            borderWidth: 3,
            hoverOffset: 3,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: {
            legend: {
                position: 'bottom',
                labels: { color: ink, boxWidth: 12, padding: 14, font: { size: 10.5 } }
            },
            tooltip: {
                backgroundColor: '#FBF7EE',
                bodyColor: ink,
                borderColor: '#C9BEA4',
                borderWidth: 1,
            }
        }
    }
});

// 3. Buttons — honest, short feedback states. No fake network delay theatre.
const syncBtn = document.getElementById('sync-btn');
const activityList = document.getElementById('activity-list');

function timeNow() {
    const d = new Date();
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function addActivityLine(text) {
    const item = document.createElement('div');
    item.className = 'activity-item is-new';
    item.innerHTML = `<span class="activity-time">${timeNow()}</span><span class="activity-text">${text}</span>`;
    activityList.prepend(item);
    // keep the list short
    while (activityList.children.length > 6) {
        activityList.removeChild(activityList.lastElementChild);
    }
    setTimeout(() => item.classList.remove('is-new'), 1500);
}

syncBtn.addEventListener('click', () => {
    syncBtn.disabled = true;
    syncBtn.textContent = 'Syncing…';
    setTimeout(() => {
        syncBtn.disabled = false;
        syncBtn.textContent = 'Sync data';
        addActivityLine('Ledger synced — figures refreshed.');
    }, 700);
});

const exportBtn = document.getElementById('export-btn');
exportBtn.addEventListener('click', () => {
    exportBtn.disabled = true;
    const original = exportBtn.textContent;
    exportBtn.textContent = 'Preparing…';
    setTimeout(() => {
        exportBtn.textContent = 'Saved';
        addActivityLine('Transactions exported to CSV.');
        setTimeout(() => {
            exportBtn.textContent = original;
            exportBtn.disabled = false;
        }, 1400);
    }, 600);
});
