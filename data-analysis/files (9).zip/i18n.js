// The Ledger — translations and i18n helpers.
// Two languages: English (ltr) and Arabic (rtl). Everything user-facing
// routes through t(key) so the whole UI can flip without a reload.

const STRINGS = {
    en: {
        title: "The Ledger",
        subDemo: "A private ledger of small-business figures — sample data. Upload a CSV to enter your own.",
        subFile: (name, count) => `Ledger of ${count} entries, drawn from ${name}.`,
        loadSample: "Load sample data",
        exportCsv: "Export CSV",
        uploadCsv: "Upload CSV",
        dropTitle: 'Drop a transactions CSV here, or use "Upload CSV" above',
        dropSub: "Expected columns: order, customer, amount, date, method, category, status",
        downloadTemplate: "Download template",
        fSearch: "Search", fSearchPh: "Customer or order #",
        fFrom: "From", fTo: "To",
        fCategory: "Category", fMethod: "Method", fStatus: "Status",
        fReset: "Reset filters",
        allCategories: "All categories", allMethods: "All methods", allStatuses: "All statuses",
        kpiRevenue: "Gross revenue", kpiRepeat: "Repeat customers",
        kpiFulfillment: "Fulfillment rate", kpiAov: "Avg. order value",
        panelRevenue: "Revenue & order volume, by month",
        panelCategory: "Revenue by category",
        panelTopCustomers: "Top customers",
        panelMethod: "Payment methods",
        panelTransactions: "Transactions",
        panelActivity: "Activity",
        colOrder: "Order", colCustomer: "Customer", colAmount: "Amount",
        colDate: "Date", colCategory: "Category", colMethod: "Method", colStatus: "Status",
        statusFulfilled: "Fulfilled", statusPending: "Pending",
        showMore: (n) => `Show ${n} more`,
        showLess: "Show fewer",
        backToPortfolio: "Back to portfolio",
        footNote: "Built by Ahmed Sobhy — upload your own transaction data, or explore the bundled sample dataset.",
        emptyState: "No transactions loaded yet. Upload a CSV or load the sample dataset above.",
        noMatches: "No transactions match the current filters.",
        revenueLegend: "Revenue", ordersLegend: "Orders",
        actSynced: "Data loaded — dashboard refreshed.",
        actUploaded: (n) => `Imported ${n} transactions from CSV.`,
        actSample: (n) => `Loaded ${n} sample transactions.`,
        actExported: (n) => `Exported ${n} transactions to CSV.`,
        actFiltered: (n) => `Filters applied — ${n} transactions shown.`,
        actLangSwitch: "Language switched to Arabic.",
        errParse: "Couldn't read that file — check it's a valid CSV.",
        errColumns: (cols) => `Missing required column(s): ${cols.join(", ")}.`,
        errEmpty: "That CSV has no usable rows.",
        vsPrevPeriod: "vs. previous period",
        ptsShort: "pts",
        txnCount: (n) => `${n} entries`,
        addTxn: "Add entry",
        modalTitle: "New ledger entry",
        mCustomer: "Customer name",
        mAmount: "Amount",
        mDate: "Date",
        mMethodCard: "Card", mMethodTransfer: "Transfer", mMethodCash: "Cash",
        mCancel: "Cancel",
        mSave: "Add entry",
        actAdded: (name) => `Added a new entry for ${name}.`,
        errCustomer: "Enter a customer name.",
        errAmount: "Enter a valid amount greater than zero.",
        errDate: "Choose a valid date.",
    },
    ar: {
        title: "الدفتر",
        subDemo: "دفتر حسابات خاص لأرقام مشروعك الصغير — بيانات نموذجية. ارفع ملف CSV لتُدخل بياناتك.",
        subFile: (name, count) => `دفتر من ${count} قيدًا، مأخوذ من ${name}.`,
        loadSample: "تحميل بيانات نموذجية",
        exportCsv: "تصدير CSV",
        uploadCsv: "رفع CSV",
        dropTitle: 'اسحب ملف معاملات CSV هنا، أو استخدم زر "رفع CSV" أعلاه',
        dropSub: "الأعمدة المطلوبة: order, customer, amount, date, method, category, status",
        downloadTemplate: "تحميل نموذج الملف",
        fSearch: "بحث", fSearchPh: "اسم العميل أو رقم الطلب",
        fFrom: "من", fTo: "إلى",
        fCategory: "الفئة", fMethod: "طريقة الدفع", fStatus: "الحالة",
        fReset: "إعادة ضبط الفلاتر",
        allCategories: "كل الفئات", allMethods: "كل الطرق", allStatuses: "كل الحالات",
        kpiRevenue: "إجمالي الإيرادات", kpiRepeat: "عملاء متكررون",
        kpiFulfillment: "معدل التنفيذ", kpiAov: "متوسط قيمة الطلب",
        panelRevenue: "الإيرادات وعدد الطلبات شهريًا",
        panelCategory: "الإيرادات حسب الفئة",
        panelTopCustomers: "أفضل العملاء",
        panelMethod: "طرق الدفع",
        panelTransactions: "المعاملات",
        panelActivity: "النشاط",
        colOrder: "الطلب", colCustomer: "العميل", colAmount: "المبلغ",
        colDate: "التاريخ", colCategory: "الفئة", colMethod: "طريقة الدفع", colStatus: "الحالة",
        statusFulfilled: "منفَّذ", statusPending: "قيد التنفيذ",
        showMore: (n) => `عرض ${n} إضافية`,
        showLess: "عرض أقل",
        backToPortfolio: "العودة إلى الملف الشخصي",
        footNote: "من تصميم أحمد صبحي — ارفع بيانات معاملاتك الخاصة، أو جرّب مجموعة البيانات النموذجية.",
        emptyState: "لا توجد معاملات بعد. ارفع ملف CSV أو حمّل البيانات النموذجية أعلاه.",
        noMatches: "لا توجد معاملات مطابقة للفلاتر الحالية.",
        revenueLegend: "الإيرادات", ordersLegend: "الطلبات",
        actSynced: "تم تحميل البيانات — تحديث لوحة التحكم.",
        actUploaded: (n) => `تم استيراد ${n} معاملة من ملف CSV.`,
        actSample: (n) => `تم تحميل ${n} معاملة نموذجية.`,
        actExported: (n) => `تم تصدير ${n} معاملة إلى CSV.`,
        actFiltered: (n) => `تم تطبيق الفلاتر — ${n} معاملة معروضة.`,
        actLangSwitch: "تم تغيير اللغة إلى الإنجليزية.",
        errParse: "تعذّرت قراءة الملف — تأكد أنه CSV صالح.",
        errColumns: (cols) => `أعمدة مطلوبة مفقودة: ${cols.join("، ")}.`,
        errEmpty: "ملف الـCSV هذا لا يحتوي على صفوف قابلة للاستخدام.",
        vsPrevPeriod: "مقارنة بالفترة السابقة",
        ptsShort: "نقطة",
        txnCount: (n) => `${n} سجل`,
        addTxn: "إضافة قيد",
        modalTitle: "قيد جديد",
        mCustomer: "اسم العميل",
        mAmount: "المبلغ",
        mDate: "التاريخ",
        mMethodCard: "بطاقة", mMethodTransfer: "تحويل", mMethodCash: "نقدًا",
        mCancel: "إلغاء",
        mSave: "إضافة القيد",
        actAdded: (name) => `تمت إضافة قيد جديد باسم ${name}.`,
        errCustomer: "من فضلك أدخل اسم العميل.",
        errAmount: "من فضلك أدخل مبلغًا صحيحًا أكبر من صفر.",
        errDate: "من فضلك اختر تاريخًا صحيحًا.",
    }
};

const STATE = { lang: localStorage.getItem("ledger-lang") || "en" };

function t(key, ...args) {
    const entry = STRINGS[STATE.lang][key];
    return typeof entry === "function" ? entry(...args) : entry;
}

function applyStaticTranslations() {
    document.documentElement.lang = STATE.lang;
    document.documentElement.dir = STATE.lang === "ar" ? "rtl" : "ltr";
    document.querySelectorAll("[data-i18n]").forEach(el => {
        const key = el.getAttribute("data-i18n");
        if (STRINGS[STATE.lang][key] !== undefined) el.innerHTML = t(key);
    });
    document.querySelectorAll("[data-i18n-ph]").forEach(el => {
        const key = el.getAttribute("data-i18n-ph");
        if (STRINGS[STATE.lang][key] !== undefined) el.placeholder = t(key);
    });
}

function fmtCurrency(n) {
    const locale = STATE.lang === "ar" ? "ar-EG-u-nu-latn" : "en-US";
    return "$" + Number(n).toLocaleString(locale, { maximumFractionDigits: 0 });
}

function fmtNumber(n) {
    const locale = STATE.lang === "ar" ? "ar-EG-u-nu-latn" : "en-US";
    return Number(n).toLocaleString(locale, { maximumFractionDigits: 1 });
}

function fmtDate(d) {
    const locale = STATE.lang === "ar" ? "ar-EG-u-nu-latn" : "en-US";
    return new Date(d).toLocaleDateString(locale, { month: "short", day: "2-digit", year: "numeric" });
}

function monthLabel(monthIdx) {
    const namesEn = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const namesAr = ["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"];
    return (STATE.lang === "ar" ? namesAr : namesEn)[monthIdx];
}
